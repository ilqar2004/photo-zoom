
// $(".photo").mouseenter(function(){
// // //  console.log("ok");
//     $(this).css("cursor: zoom-in;");
// });


// $("#zoom1").elevateZoom({});
// $("#zoom1").elevateZoom({scrollZoom : true});
$("#zoom1").elevateZoom({scrollZoom: true,tint:true, tintColour:'forestgreen', tintOpacity:0.5});













// $(function(){
//     //Jquery kodu
// })

// $(document).ready( function(){
//         //Jquery kodu
// } )



$(function(){


    // jQuery('h1').css({
    //     "color" : "red",
    //     "font-size" : "30px",
    //     'background-color' : "blue",
    // });

    // $('h1').css({
    //     "color" : "red",
    //     "font-size" : "30px",
    //     'background-color' : "blue",
    // });

// $('button').click(function(){
//     $('h1').css('color', 'red');
// })


// $('h1').on('click mouseleave', function(){
//     $(this).css('color', 'red');
// })



// $('h1').on( {
//     'click' : function(){
//         $(this).css('color', 'red');
//     },
//     'mouseleave' : function(){
//         $(this).css('color', 'green');
//     },

//     'mouseenter' : function(){
//         $(this).css({
//             'cursor' : 'pointer',
//             'color' : "yellow"
//         });
//     },
// } )



// $('button').click(function(){
//     $('h1').addClass('active');
// })

// $('button').click(function(){
//     $('h1').removeClass('active');
// })

// $('button').click(function(){
//     $('h1').toggleClass('active');
// })


$('.hamb').click(function(){
    $('nav').toggleClass('active');
    $(this).toggleClass('aktiv');
})




})